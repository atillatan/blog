package com.atilla.exchangerates.provider;

/**
 * @author Atilla Tanrikulu
 * 
 */
public abstract class ThirdPartyProvider {

	protected ThirdPartyProvider() {
	}

}