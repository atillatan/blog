/**
 * 
 */
package com.atilla.exchangerates.provider;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.atilla.exchangerates.common.CurrencyEnum;
import com.atilla.exchangerates.common.RateDTO;
import com.atilla.exchangerates.common.RateListDTO;

/**
 * @author Atilla Tanrikulu
 * 
 */
@Component
public class ExchangeRatesAPIProvider extends ThirdPartyProvider implements RateProvider {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	// private static final ObjectMapper objectMapper = new ObjectMapper();

	@Value(value = "${provider.exchangeratesapi.host:https://api.exchangeratesapi.io}")
	private String host;

	public ExchangeRatesAPIProvider() {

	}

	private Calendar calendar = Calendar.getInstance();

	private RestTemplate restTemplate = new RestTemplate();

	@Override
	public RateDTO callProviderApi(CurrencyEnum baseCurrency) {

		calendar.add(Calendar.DATE, -1);

		// Requirement: the average of the five days before the requested date
		// (excluding Saturday and Sunday )
		while (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
				|| calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
			calendar.add(Calendar.DATE, -1);
		}

		StringBuilder sbDate = new StringBuilder();
		sbDate.append(calendar.get(Calendar.YEAR)).append("-");
		sbDate.append(calendar.get(Calendar.MONTH) + 1).append("-");
		sbDate.append(calendar.get(Calendar.DAY_OF_MONTH));

		RateDTO rate = null;

		try {
			logger.info("Call provider API:" + host + "/" + sbDate.toString() + "?base=" + baseCurrency);
			rate = restTemplate.getForObject(host + "/" + sbDate.toString() + "?base=" + baseCurrency, RateDTO.class);
		} catch (Exception e) {
			logger.error("API call error", e);
			throw e;
		}

		logger.info("Response received from provider API:" + rate.toString());

		return rate;
	}

	@Override
	public RateListDTO callProviderApi(CurrencyEnum baseCurrency, String start_at, String end_at) {

		StringBuilder sbParams = new StringBuilder();
		sbParams.append("/history?base=").append(baseCurrency.toString());
		sbParams.append("&start_at=").append(start_at);
		sbParams.append("&end_at=").append(end_at);

		RateListDTO rateList = null;

		try {
			logger.info("Call provider API:" + host + sbParams.toString());
			rateList = restTemplate.getForObject(host + sbParams.toString(), RateListDTO.class);
		} catch (Exception e) {
			logger.error("API call error", e);
			throw e;
		}

		logger.info("Response received from provider API:" + rateList.toString());

		return rateList;
	}
}