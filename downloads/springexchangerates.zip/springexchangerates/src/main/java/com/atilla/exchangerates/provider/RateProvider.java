package com.atilla.exchangerates.provider;

import com.atilla.exchangerates.common.CurrencyEnum;
import com.atilla.exchangerates.common.RateDTO;
import com.atilla.exchangerates.common.RateListDTO;
 
/**
 * @author Atilla Tanrikulu
 * 
 */
public interface RateProvider {

	RateDTO callProviderApi(CurrencyEnum baseCurrency);
	
	RateListDTO callProviderApi(CurrencyEnum baseCurrency, String start_at, String end_at);
}
