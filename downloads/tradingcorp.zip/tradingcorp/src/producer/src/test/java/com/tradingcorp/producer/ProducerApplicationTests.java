package com.tradingcorp.producer;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;

import com.tradingcorp.producer.controller.TradeController;

import static org.assertj.core.api.Assertions.assertThat;



@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class ProducerApplicationTests {

	@Autowired
	private TradeController controller;

	@Autowired(required=true)
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	@Test
	public void contextLoads() throws Exception {
		assertThat(controller).isNotNull();
	}

	@Test
	public void postTradeMessage() throws Exception {

		String url = "http://localhost:" + port + "/"
				+ "tradeId=1&version=1&counterParty=CP1&bookId=b1&maturityDate=2017-08-04&createdDate=2017-08-04&expiredFlag=N";

		assertThat(this.restTemplate.postForLocation(url, String.class));
	}

}
