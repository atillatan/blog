package com.tradingcorp.consumer.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.tradingcorp.common.model.Trade;
import com.tradingcorp.consumer.repository.TradeRepository;

@Service
public class TradeConsumerService {

	private final Logger logger = LoggerFactory.getLogger(TradeConsumerService.class);

	private final TradeRepository tradeRepository;

	@Autowired
	public TradeConsumerService(TradeRepository tradeRepository) {
		this.tradeRepository = tradeRepository;
	}

	public void saveTrade(Trade trade) {
		tradeRepository.save(trade);
		logger.info(String.format("Trade inserted to databse -> %s", trade));
	}

	public Trade findById(Long id) {
		return tradeRepository.findById(id).get();
	}

	// 1- Using Consumer Group
	@KafkaListener(topics = "${trade.topic.name}", groupId = "${spring.kafka.consumer.group-id", containerFactory = "kafkaListenerContainerFactory")
	public void consume(Trade trade) {

		logger.info(String.format("Trade consume -> %s", trade));

		// Validation
		if (trade.getTradeId().startsWith("fail")) {
			throw new RuntimeException("failed");
		}

		// Save
		this.saveTrade(trade);

		logger.info(String.format("Trade created -> %s", trade));
	}
}
