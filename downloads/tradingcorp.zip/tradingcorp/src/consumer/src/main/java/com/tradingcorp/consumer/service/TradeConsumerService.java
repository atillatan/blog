package com.tradingcorp.consumer.service;

import com.tradingcorp.model.InvalidTradeException;
import com.tradingcorp.model.Trade;

public interface TradeConsumerService {
	void consume(Trade trade) throws InvalidTradeException;
}
