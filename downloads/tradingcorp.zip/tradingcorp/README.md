
# Problem Statement

There is a scenario where thousands of trades are flowing into one store, assume any way of transmission of trades (could be receiving the trades via Kafka or MQ or…).

We need to create a one trade store, which stores the trade (any kind of database) in the following order:


| Trade Id | Version | Counter-Party Id | Book-Id | Maturity Date | Created Date | Expired |
| -------- | ------- | ---------------- | ------- | ------------- | ------------ | ------- |
| T1       | 1       | CP-1             | B1      | 20/05/2020    | today date   | N       |
| T2       | 2       | CP-2             | B1      | 20/05/2021    | today date   | N       |
| T2       | 1       | CP-1             | B1      | 20/05/2021    | 14/03/2015   | N       |
| T3       | 3       | CP-3             | B2      | 20/05/2014    | today date   | Y       |


**Application to be created:**

1. Producer
1. Consumer
1. Validation to be applied  
1. Junit test Case to be written on Components
1. Architecture document  


## 1. Solutions

- **Producer:** Spring Boot java application implemented. The application name is "producer"
- **Consumer:** Spring Boot java application implemented. The application name is "consumer" 
- **Validation to be applied :** Transaction management has been made using "KafkaTransactionManager"
AOP approach was applied for "Exception Handling", Specific Spring component name is "ControllerAdvice".
for "Data Validation", validation method has been implemented on the service layer.    
- **Junit test Case to be written on Components** Unit test methods have been developed under the test project in both projects. 
- **Architecture document:** The architectural structure is presented in this document. 

## 2. Scenario 1

- We have one "producer" and one "consumer". They communicate using 3  Kafka Broker, 3 Partition

![20210211-s1.png](_assets/20210211-s1.png)

### 2.1 Implementation Details

#### 2.1.1  Producer 

Configuration: application.propertis
```properties
server.port=8081
spring.kafka.producer.bootstrap-servers: localhost:9092, localhost:9093, localhost:9094
spring.kafka.producer.key-serializer: org.apache.kafka.common.serialization.StringSerializer
spring.kafka.producer.value-serializer: org.springframework.kafka.support.serializer.JsonSerializer

trade.topic.name: trade-topic
trade.topic.partition.count: 3
# We will set different hashkey for different producer instances
trade.topic.producer.target.partition.hashkey: P1 

```

Spring RestController for RESTful api requests

```java
@RestController
public class TradeController {

	private final Logger logger = LoggerFactory.getLogger(TradeController.class);

	private TradeProducerService tradeService;

	@Autowired
	public TradeController(TradeProducerService tradeService) {
		this.tradeService = tradeService;
	}

	@PostMapping(path = "/post-trade")
	public void sendTrade(
			@RequestParam("tradeId") String tradeId, 
			@RequestParam("version") int version,
			@RequestParam("counterParty") String counterParty, 
			@RequestParam("bookId") String bookId,
			@RequestParam("maturityDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate maturityDate, 
			@RequestParam("createdDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate createdDate,
			@RequestParam("expiredFlag") String expiredFlag) {

    Trade trade = new Trade();
		trade.setTradeId(tradeId);
		trade.setVersion(version);
		trade.setCounterParty(counterParty);
		trade.setBookId(bookId);
		trade.setMaturityDate(maturityDate);
		trade.setCreatedDate(createdDate);
		trade.setExpiredFlag(expiredFlag);

		logger.info(String.format("RESTful request -> %s", trade));	
		
		// Validation to be applied  
       if(tradeService.isValid(trade)) {    	   
    	   this.tradeService.sendMessageWithCallBack(trade);
       }else{
          // return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
           throw new InvalidTradeException(trade.getTradeId()+"  Trade Id is not found");
       }       
	}
}

```

Transactional Service layer: 

```java
@Service
public class TradeProducerService {
//...

  // Asynchronous
	@Transactional
	public void sendMessageWithCallBack(Trade trade) {

		ListenableFuture<SendResult<String, Trade>> future = this.kafkaTemplate.send(tradeTopicName, trade);
		future.addCallback(new ListenableFutureCallback<SendResult<String, Trade>>() {

       			@Override
			public void onSuccess(SendResult<String, Trade> result) {
				logger.info("Trade sent: " + trade + " with offset: " + result.getRecordMetadata().offset());
			}
      
			@Override
			public void onFailure(Throwable ex) {
				logger.error("Trade sent : " + trade, ex);
			}
		});
	}


//...
}
```

Producer Configuration:

```java
@Configuration
public class KafkaProducerConfig {

	@Value(value = "${spring.kafka.producer.bootstrap-servers}")
	private String bootstrapAddress;

	@Bean
	public ProducerFactory<String, Trade> tradeProducerFactory() {
		Map<String, Object> configProps = new HashMap<>();
		configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

		DefaultKafkaProducerFactory<String, Trade> factory = new DefaultKafkaProducerFactory<>(configProps);
		factory.transactionCapable();
		factory.setTransactionIdPrefix("tran-");

		return factory;
	}

	@Bean
	public KafkaTransactionManager<String, Trade> transactionManager(ProducerFactory<String, Trade> producerFactory) {
		KafkaTransactionManager<String, Trade> manager = new KafkaTransactionManager<String, Trade>(producerFactory);
		return manager;
	}

	@Bean
	public KafkaTemplate<String, Trade> tradeKafkaTemplate() {
		return new KafkaTemplate<>(tradeProducerFactory());
	}
}
```


#### 2.1.2 Consumer

Configuration: application.propertis
```properties
server.port=8082
spring.kafka.consumer.bootstrap-servers: localhost:9092, localhost:9093, localhost:9094
# Every consumer group has a group coordinator. If a consumer stops sending heartbeats, the coordinator will trigger a rebalance.
spring.kafka.consumer.group-id: trade-consumer-group
spring.kafka.consumer.auto-offset-reset: earliest
spring.kafka.consumer.key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
spring.kafka.consumer.value-deserializer: org.springframework.kafka.support.serializer.JsonDeserializer
spring.kafka.consumer.properties.spring.json.trusted.packages=*

trade.topic.name: trade-topic

spring.datasource.url=jdbc:postgresql://localhost:5432/postgres
spring.datasource.username=postgres
spring.datasource.password=123
spring.jpa.hibernate.ddl-auto=create-drop
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQLDialect
spring.jpa.properties.hibernate.format_sql=true

```

KaffaListener located in Service Layer, it consumes topic data, It has Consumer Group configuration as well.

```java
@Service
public class TradeConsumerService {

	private final Logger logger = LoggerFactory.getLogger(TradeConsumerService.class);

	private final TradeRepository tradeRepository;

	@Autowired
	public TradeConsumerService(TradeRepository tradeRepository) {
		this.tradeRepository = tradeRepository;
	}

	public void saveTrade(Trade trade) {
		tradeRepository.save(trade);
		logger.info(String.format("Trade inserted to databse -> %s", trade));
	}

	public Trade findById(Long id) {
		return tradeRepository.findById(id).get();
	}

	// 1- Using Consumer Group
	@KafkaListener(topics = "${trade.topic.name}", groupId = "${spring.kafka.consumer.group-id", containerFactory = "kafkaListenerContainerFactory")
	public void consume(Trade trade) {

		logger.info(String.format("Trade consume -> %s", trade));

		// Validation
		if (trade.getTradeId().startsWith("fail")) {
			throw new RuntimeException("failed");
		}

		// Save
		this.saveTrade(trade);

		logger.info(String.format("Trade created -> %s", trade));
	}
}

```

Kafka Consumer Configuration:
```java
@EnableKafka
@Configuration
public class KafkaConsumerConfig {

	@Value(value = "${spring.kafka.consumer.bootstrap-servers}")
	private String bootstrapAddress;

	@Value(value = "${spring.kafka.consumer.group-id}")
	private String tradeGroupId;

	// Consumer-1

	public ConsumerFactory<String, Trade> consumerFactory() {
		Map<String, Object> props = new HashMap<>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
		props.put(ConsumerConfig.GROUP_ID_CONFIG, tradeGroupId);
		props.put(JsonDeserializer.TRUSTED_PACKAGES, "*");
		return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), new JsonDeserializer<>(Trade.class));
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, Trade> kafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, Trade> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory());
		return factory;
	}

}
```

### 2.2 Scenario 1 - Setup and Run

**Requirements:**

1. Docker
2. ProstgreSQL Docker Container
3. Zookeeper
4. Kafka 
5. Maven
6. Producer Java app
7. Consumer Java app

----

1. Install "Docker" https://docs.docker.com/get-docker/
2. Download "Postgresql" docker container with following terminal command

```bash
$ docker pull postgres
```
PostgreSQL configuration: Run following commands in Terminal

```bash
$ docker run --name postgres1 -p 5432:5432 -e POSTGRES_PASSWORD=123 -d postgres

$ docker ps

$ docker exec -it postgres1 bash

$ su postgres

$ psql

$ DROP TABLE IF EXISTS trades;
$ CREATE TABLE Trade(id serial PRIMARY KEY, tradeId VARCHAR(255), version integer, counterparty VARCHAR(255), bookid VARCHAR(255),maturityDate DATE, createddate DATE, expiredFlag VARCHAR(255));

```

3. Zookeeper

Zookeeper located in Kafka folder, installation not required. 

4. Kafka

Download https://kafka.apache.org/downloads Kafka and extract files, installation not required.

- Copy following files 

```bash
tradingcorp/resources/kafka/server.properties
tradingcorp/resources/kafka/server-1.properties
tradingcorp/resources/kafka/server-2.properties
```
into `{Kafka Folder}/config/`folder

- run following commands in terminal windows

```bash
# go into kafka bin directory
cd bin

# run each commands in different terminal window

# Start the ZooKeeper service
$ ./zookeeper-server-start.sh ../config/zookeeper.properties

# Start the Kafka broker service
$ ./kafka-server-start.sh ../config/server.properties

# Start the Kafka broker service
$ ./kafka-server-start.sh ../config/server-1.properties

# Start the Kafka broker service
$ ./kafka-server-start.sh ../config/server-2.properties

# list topics
$ ./kafka-topics.sh --list --zookeeper localhost:2181

```


5. Install Maven with following guide: https://maven.apache.org/install.html
6. Run following commands in Terminal window

```bash
$ cd src/producer     
$ producer mvn package
$ cd ../consumer
$ mvn package
```



Following picture shows terminal windows

Berore running:

![20210211-s3](_assets/20210211-s3.png)

producer and consumer started:

![20210211-s4](_assets/20210211-s4.png)

Producer sent message to kafka, Consumer took message and inserted into database:

![20210211-s5](_assets/20210211-s5.png)

Database view:

![20210211-s7](_assets/20210211-s7.png)


## 3. Scenario 2

We have 3 "producer" and 3 "consumer". They communicate using 3  Kafka Broker, 3 Partition

![20210211-s2.png](_assets/20210211-s2.png)


## 

 

 **Requirements:**

1. Run 3 instance of "Producer" application

2. We will add 2 more consumer into "Consumer" application. All 3 Consumers will use same "group-id"

---

   

1. We will modify `application.properties' for additional copies like below.

![20210211-8](_assets/20210211-8.png)



